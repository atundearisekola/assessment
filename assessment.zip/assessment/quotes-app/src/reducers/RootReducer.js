import {combineReducers} from 'redux';
import QoutesReducer from './QoutesReducer';




const RootReducer = combineReducers({QoutesReducer,})

export default RootReducer;
